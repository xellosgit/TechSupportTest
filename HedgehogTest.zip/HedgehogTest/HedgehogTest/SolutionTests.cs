﻿using System;
using System.Linq;
using NUnit.Framework;
namespace HedgehogTest
{
    [TestFixture]
    public class SolutionTests
    {
        [Test]
        public void BasicTests()
        {
            // Тест 1: Можливо досягти цільового кольору
            int[] population1 = new int[] { 8, 1, 9 };
            int targetColor1 = 0;
            int result1 = Solution.MinMeetings(population1, targetColor1);
            Assert.That(result1, Is.EqualTo(5));
            Console.WriteLine($"Тест 1: population = [{string.Join(", ", population1)}], targetColor = {targetColor1}, результат = {result1}");

            // Тест 2: Вже всі потрібного кольору
            int[] population2 = new int[] { 5, 0, 0 };
            int targetColor2 = 0;
            int result2 = Solution.MinMeetings(population2, targetColor2);
            Assert.That(result2, Is.EqualTo(0));
            Console.WriteLine($"Тест 2: population = [{string.Join(", ", population2)}], targetColor = {targetColor2}, результат = {result2}");

            // Тест 3: Неможливо досягти цільового кольору
            int[] population3 = new int[] { 1, 0, 0 };
            int targetColor3 = 1;
            int result3 = Solution.MinMeetings(population3, targetColor3);
            Assert.That(result3, Is.EqualTo(-1));
            Console.WriteLine($"Тест 3: population = [{string.Join(", ", population3)}], targetColor = {targetColor3}, результат = {result3} (неможливо досягти цільового кольору)");

            // Тест 4: Рівна кількість двох кольорів
            int[] population4 = new int[] { 2, 2, 0 };
            int targetColor4 = 0;
            int result4 = Solution.MinMeetings(population4, targetColor4);
            Assert.That(result4, Is.EqualTo(2));
            Console.WriteLine($"Тест 4: population = [{string.Join(", ", population4)}], targetColor = {targetColor4}, результат = {result4}");

            // Тест 5: Великі числа
            int[] population5 = new int[] { 0, 50000, 50000 };
            int targetColor5 = 0;
            int result5 = Solution.MinMeetings(population5, targetColor5);
            Assert.That(result5, Is.EqualTo(50000));
            Console.WriteLine($"Тест 5: population = [{string.Join(", ", population5)}], targetColor = {targetColor5}, результат = {result5}");
        }

        [Test]
        public void EdgeCases()
        {
            // Тест 6: Некоректні вхідні дані
            int[]? nullArray = null;
            int result6a = Solution.MinMeetings(nullArray, 0);
            Assert.That(result6a, Is.EqualTo(-1));
            Console.WriteLine($"Тест 6a: population = null, targetColor = 0, результат = {result6a} (некоректні вхідні дані)");

            int[] population6b = new int[] { 1, 1 };
            int result6b = Solution.MinMeetings(population6b, 0);
            Assert.That(result6b, Is.EqualTo(-1));
            Console.WriteLine($"Тест 6b: population = [{string.Join(", ", population6b)}], targetColor = 0, результат = {result6b} (некоректні вхідні дані)");

            int[] population6c = new int[] { 1, 1, 1 };
            int result6c = Solution.MinMeetings(population6c, -1);
            Assert.That(result6c, Is.EqualTo(-1));
            Console.WriteLine($"Тест 6c: population = [{string.Join(", ", population6c)}], targetColor = -1, результат = {result6c} (некоректні вхідні дані)");

            int result6d = Solution.MinMeetings(population6c, 3);
            Assert.That(result6d, Is.EqualTo(-1));
            Console.WriteLine($"Тест 6d: population = [{string.Join(", ", population6c)}], targetColor = 3, результат = {result6d} (некоректні вхідні дані)");

            // Тест 7: Від'ємні числа в популяції
            int[] population7 = new int[] { -1, 1, 1 };
            int result7 = Solution.MinMeetings(population7, 0);
            Assert.That(result7, Is.EqualTo(-1));
            Console.WriteLine($"Тест 7: population = [{string.Join(", ", population7)}], targetColor = 0, результат = {result7} (від'ємні числа в популяції)");
        }
    }
}