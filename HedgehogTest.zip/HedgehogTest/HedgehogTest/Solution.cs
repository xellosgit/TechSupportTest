﻿using System;
using System.Linq;

namespace HedgehogTest
{
    public class Solution
    {
        public static int MinMeetings(int[]? population, int targetColor)
        {
            // Перевірка вхідних даних
            if (population == null || population.Length != 3 ||
                targetColor < 0 || targetColor > 2 ||
                population.Any(x => x < 0))
                return -1;

            int[] curr = population.ToArray();
            int total = curr.Sum();

            // Перевірка на переповнення
            if (total < 1 || total > int.MaxValue)
                return -1;

            // Якщо всі їжачки вже потрібного кольору
            if (curr[targetColor] == total)
                return 0;

            // Визначення індексів інших кольорів
            int color1 = (targetColor + 1) % 3;
            int color2 = (targetColor + 2) % 3;

            int nonTargetCount = curr[color1] + curr[color2];

            // Якщо неможливо досягти мети
            if (nonTargetCount == 0 || nonTargetCount % 2 != 0)
                return -1;

            // Визначення мінімальної кількості зустрічей
            if (curr[color1] == 0 || curr[color2] == 0)
            {
                // Всі їжачки одного нецільового кольору
                return nonTargetCount; // Дві зустрічі на кожну пару
            }

            // Їжачки різних кольорів
            return nonTargetCount / 2;
        }
    }
}